﻿using WebApi.Middleware;

namespace WebApi.Exceptions
{
  public static class ApiException
  {
    public static void UseErrorHandlingMiddleware(this IApplicationBuilder app)
    {
      app.UseMiddleware<ErrorHandlerMiddleware>();
    }
  }
}
