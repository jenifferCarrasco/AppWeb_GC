﻿using Application.Interfaces;

namespace Shared.Services
{
  public class DateTimeService : IDateTimeService
  {
    public DateTime NewUtc => DateTime.UtcNow;

    DateTime IDateTimeService.NewUtc { get => NewUtc; set => throw new NotImplementedException(); }
  }
}
