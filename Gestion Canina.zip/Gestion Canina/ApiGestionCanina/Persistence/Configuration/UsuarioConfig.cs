﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Persistence.Configuration
{
  public class PropietarioConfig : IEntityTypeConfiguration<Propietario>
  {
    public void Configure(EntityTypeBuilder<Propietario> builder)
    {
      builder.ToTable("Usuarios");
      builder.HasKey(x => x.UsuarioId);

      builder.Property(x => x.Nombre)
        .HasMaxLength(100)
        .IsRequired();

      builder.Property(x => x.Apellido)
        .HasMaxLength(100)
        .IsRequired();

      builder.Property(x => x.Sexo)
        .HasMaxLength(1)
        .IsRequired();

      builder.Property(x => x.Email)
        .HasMaxLength(100)
        .IsRequired();

      builder.Property(x => x.FechaNacimiento)
        .IsRequired();

      builder.Property(x => x.Edad);

      builder.Property(x => x.Direccion)
        .HasMaxLength(200)
        .IsRequired();

      builder.Property(x => x.Telefono)
        .HasMaxLength(9)
        .IsRequired();

      builder.Property(x => x.CreatedBy)
        .HasMaxLength(30)
        .IsRequired();

      builder.Property(x => x.LastModifiedBy)
        .HasMaxLength(30)
        .IsRequired();

      builder.HasMany(x => x.Pacientes)
        .WithOne(x => x.Propietario)
        .HasForeignKey(x => x.PacientesId);

      builder.Property(x => x.FirebaseId)
        .IsRequired();

    }
  }
}
