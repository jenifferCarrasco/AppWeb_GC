﻿namespace Domain.Entities
{
  public class Propietario : AuditableBaseEntity
  {
    private int _edad;
    public int UsuarioId { get; set; }
    public string? Nombre { get; set; }
    public string? Apellido { get; set; }
    public DateTime FechaNacimiento { get; set; }
    public string? Telefono { get; set; }
    public string? Direccion { get; set; }
    public string? Sexo { get; set; }
    public string? Email { get; set; }
    public int FirebaseId { get; set; }
    public int PacientesId { get; set; }
    public List<Paciente>? Pacientes { get; set; }
    public int Edad
    {

      get
      {
        if (this.Edad <= 0)
        {
          this._edad = new DateTime(DateTime.Now.Subtract(this.FechaNacimiento).Ticks).Year - 1;
        }
        return this._edad;
      }

    }

  }
}
