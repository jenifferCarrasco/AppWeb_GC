﻿namespace Domain.Entities
{
  public class Cita
  {
  }
}
