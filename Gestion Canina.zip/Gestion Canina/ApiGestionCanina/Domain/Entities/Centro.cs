﻿namespace Domain.Entities
{
  public class Centro : AuditableBaseEntity
  {
    public int CentroId { get; set; }
    public string? Nombre { get; set; }
    public int? Tipo_Empresa { get; set; }
    public string? Logo { get; set; }
    public string? Direccion { get; set; }

  }
}
