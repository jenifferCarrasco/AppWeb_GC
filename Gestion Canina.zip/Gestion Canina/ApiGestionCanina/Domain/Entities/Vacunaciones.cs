﻿namespace Domain.Entities
{
  public class Vacunaciones
  {
  }
}
