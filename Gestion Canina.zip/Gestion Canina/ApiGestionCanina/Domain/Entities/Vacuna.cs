﻿namespace Domain.Entities
{
  public class Vacuna : AuditableBaseEntity
  {
    public int VacunaId { get; set; }
    public string? Nombre { get; set; }
    public string? Lote { get; set; }
    public DateTime FechaExpiracion { get; set; }

  }
}
