﻿namespace Application.Interfaces
{
  public interface IDateTimeService
  {
    public DateTime NewUtc { get; set; }
  }
}
